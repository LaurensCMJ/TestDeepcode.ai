#include "hzpch.h"
#include "Hazel/Core/Layer.h"

namespace Hazel {

	Layer::Layer(const std::string& debugName)
		: m_DebugName(debugName)
	{
	}
	
}